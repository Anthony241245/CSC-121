import csv
stu_names = ["Zakari Watson", "Jerom Williams", "Dominique Ross", "Diana Shepard", "Yoko Mayo","Rashad Ahmed","Susan Jones"]


courses = ["MAT 035(Concepts of Algebra)", "CTI 115(Computer System Foundations)","BAS 120 Intro to Analytics","CSC 121 Python Programming" ]

tuition = [460, 520.98, 500, 783.88]



def choice1():
    students = {}
    for name in stu_names:
                    student_tuition = 0
                    num_courses = 0
                    grades_total = 0
                    gpa = 0
                    if name not in students:
                        students[name] = {}
                    for i in range(4):
                    
                        print(f'Is {name} taking {courses[i]}?')
                        confirm = input('Enter "y" for yes: ')
                        if confirm == 'y':
                            # Get tuition for class
                            student_tuition += tuition[i]
                            num_courses += 1
                            grade = float(input(f"Enter {name}'s grade for {courses[i]}: "))
                            #add the grade to the grades total
                            grades_total += grade

                            # Calculate the gpa
                            gpa = grades_total / num_courses

                            
                            # Add the course and grade as the inner dict's key:value pair
                            students[name][courses[i]] = grade
                        students[name]['tuition'] = student_tuition
                        students[name]['GPA'] = gpa
    print(students)

    # Write the students dictionary to a file
    with open("output.csv", "w", newline="") as csv_file:
          fieldnames = ["Student Names", "GPA", "Tuition"]
          csv_writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
          
          csv_writer.writeheader()

          for name, details in students.items():
                csv_writer.writerow({"Student Name": name, "GPA": details["GPA"], "Tuition": details["tuition"]})



def menu():
    print("\nMenu:")
    print("1. Select Courses, Course Grade and Calc Tuition")
    print("2. Calculate tuitio for specific students")
    print("3. Display average and total tuition(All students)")
    print("4. Display student info")
    print("5. Exit")
    choice = 0
    while choice != 4:
        choice = int(input("Enter your choice: "))
        if choice == 1:
            choice1()
        
              
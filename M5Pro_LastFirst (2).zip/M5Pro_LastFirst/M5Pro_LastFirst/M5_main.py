# Anthony Raynor
# 2/13/2025
import M5_functions as fn

stu_names = ["Zakari Watson", "Jerom Williams", "Dominique Ross", "Diana Shepard", "Yoko Mayo","Rashad Ahmed","Susan Jones"]


courses = ["MAT 035(Concepts of Algebra)", "CTI 115(Computer System Foundations)","BAS 120 Intro to Analytics","CSC 121 Python Programming" ]

tuition = [460, 520.98, 500, 783.88]

def main():
    fn.menu()
    
    
        

        
                            
if __name__ == "__main__":
      main()
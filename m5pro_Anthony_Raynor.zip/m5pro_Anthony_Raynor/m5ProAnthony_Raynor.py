# Anthony Raynor
# 2/11/25
stu_names = ["Zakarri Watson", "Jerom Williams", "Dominique Ross", 'Diana shepard', "Yoko Mayo", "Rashad Ahmed", "Susan Jones"]
courses = ["MAT 035(Concepts of Algebra)", "CTI 115(Computer System Foundations)", "BAS 120 Intro to Analytics", "CSC 121 Python Programming"]
tuition = [460, 520.98, 500, 783.88]







def menu():
    print("\nMenu:")
    print("1. Select Courses, Course Grade and Calc Tuition")
    print("2. Calculate tuitio for specific students")
    print("3. Display average and total tuition(All students)")
    print("4. Display student info")
    print("5. Exit")
    choice = input("Enter your choice: ")

def show_tuition():
    registered = []
    costs = []
    print()
    
                
    print("Tuition For",f'{stu_names[select-1]}')
    print("\n",f'{"Course":<40}{"Tuition"}')
    print("-"*50)
                
    for i in range(len(registered)):
            print(f'{registered[i]:<40}${costs[i]:.2f}')
                    
            print("-"*50)
            print(f"{'Total Cost':<40}${sum(costs)}")
    else:
                
                print("Bye")





def main():
    #create  empty dictionary
    show_tuition()
    students = {}
    
    
    for name in stu_names:
         cost_per_student = 0
         crses_per_student = []
         cost=[]
         for i in range(len(tuition)):
            print(f'Is {name} taking {courses[i]}?')
            confirm = input('Enter "y" for yes: ')
            if confirm == 'y':
                if name not in students:
                         students[name] = {}
                grade = float(input(f"Enter {name}'s grade for {courses[i]}: "))
                        # Add the course and grade as the inner dict's key:value pair
                students[name][courses[i]] = grade
    print(students)
                        # add course tuition
                        #cost_per_student += tuition[i]
                        #crses_per_student.append(courses[i])
                #cost.append(cost_per_student)
               # print(f"{name}{crses_per_student}")
            # display student names and their tuition
print(f'{"Stu Name":<40}{"Tuition"}')
for i in range(len(stu_names)):
    #print(f'{stu_names[i]:<40}${cost[i]:.2f}')
    






    if __name__ == "__main__":
     main()
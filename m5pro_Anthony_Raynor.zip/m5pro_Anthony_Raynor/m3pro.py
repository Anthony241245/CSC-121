# -*- coding: utf-8 -*-
"""
Created on Tue Jan  7 20:41:54 2025

@author: seidih6290
"""


stu_names = ["Zakari Watson", "Jerom Williams", "Dominique Ross", "Diana Shepard", "Yoko Mayo","Rashad Ahmed","Susan Jones"]

courses = ["MAT 035(Concepts of Algebra)", "CTI 115(Computer System Foundations)","BAS 120 Intro to Analytics","CSC 121 Python Programming" ]

tuition = [460, 520.98, 500,783.88]

def main():
    #header row
    print()
    print(f'{"Course Name":<40}{"Tuition"}')
    print("-"*50)
    
    for i in range(len(tuition)):
        
      
        print(f'{courses[i]:<40}${tuition[i]}')
    print("-"*50)
    print()
    
    cost=[]
    
    
    
    
    choice = 0
    
    while choice !=3:
        
        menu()
        choice =int(input("Enter choice: "))
        
        if choice == 1:
            
            for name in stu_names:
                cost_per_student = 0
                crses_per_student = []
                
                for i in range(len(tuition)):
                
                    print(f'Is {name} taking {courses[i]}?')
                    confirm = input('Enter "y" for yes: ')
                    if confirm == 'y':
                        # add course tuition
                        cost_per_student += tuition[i]
                        crses_per_student.append(courses[i])
                cost.append(cost_per_student)
            # display student names and their tuition
            print(f'{"Stu Name":<40}{"Tuition"}')
            for i in range(len(stu_names)):
                print(f'{stu_names[i]:<40}${cost[i]:.2f}')
                
        elif choice == 2:
            
            # get student name

            print("\nSelect from list of student names below:\n")
            count = 0
            for name in stu_names:
                count +=1
                print(str(count)+")",name)
            select = int(input("\nEnter student Number: "))
            
            # ask again for this student
            registered = []
            costs = []
            
            for i in range(len(tuition)):
                
                print(f'Is {stu_names[select-1]} taking {courses[i]}?',end="")
                confirm = input('Enter "y" for yes: ')
                if confirm == 'y':
                        # add course tuition
                    registered.append(courses[i])
                    costs.append(tuition[i])
            #display courses and tuition
                    
            print()
            
            print("Tuition For",f'{stu_names[select-1]}')
            print("\n",f'{"Course":<40}{"Tuition"}')
            print("-"*50)
            
            for i in range(len(registered)):
                print(f'{registered[i]:<40}${costs[i]:.2f}')
                
            print("-"*50)
            print(f"{'Total Cost':<40}${sum(costs)}")
        else:
            
            print("Bye")
                
                    


def menu():
    print("-"*20,"MENU","-"*20)
    print("1) Calculate Tuition for ALL Students")
    print("2) Calculate Tuition For Specific Students")
    print("3) Exit")
    print("-"*20,"MENU","-"*20)
    
    
main()